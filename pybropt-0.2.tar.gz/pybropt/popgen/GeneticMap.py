import numpy
import pandas
from scipy.interpolate import interp1d

class GeneticMap:
    """
    A class to represent genetic maps and perform associated operations.
    """

    def __init__(self, arg):
        super(GeneticMap, self).__init__()
        self.arg = arg
        
