# stop based on iteration number

# stop after 50 iterations.
def inum50(x):
    return x < 50
