# THESE ARE ORDER DEPENDENT BASED ON INHERITANCE!!!

# MarkerSet group
from .MarkerSet import MarkerSet
from .GeneticMap import GeneticMap

# Population group
from .Population import Population

# Cross group
from .Cross import Cross
