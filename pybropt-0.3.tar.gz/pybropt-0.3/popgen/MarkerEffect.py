# import 3rd party libraries
# import numpy

# import our libraries
from . import MarkerSet
# import pybropt.util

class MarkerEffect(MarkerSet):
    """docstring for MarkerEffect."""

    def __init__(self):
        super(MarkerEffect, self).__init__()
